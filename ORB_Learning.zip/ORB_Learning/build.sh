#!/bin/bash
directory_bulid="./build"
if [  ! -f "$directory_bulid" ]
then
    echo "Catalogue build exists ! Change directory to build and clear it"
    cd build
    rm -ir ./*
else
    echo "Catalogue build doesn't exist ! Create first"
    mkdir build
    cd build 
fi
cmake ..
make
