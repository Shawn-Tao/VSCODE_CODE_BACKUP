#/bin/bash
if[ ! -f "build"]
then
    mkdir build
else
    rm -rf ./build/*
fi
if[ ! -f "bin"]
then
    mkdir bin
else
    rm -rf ./bin/*
fi
cd build
cmake ..
make -j
